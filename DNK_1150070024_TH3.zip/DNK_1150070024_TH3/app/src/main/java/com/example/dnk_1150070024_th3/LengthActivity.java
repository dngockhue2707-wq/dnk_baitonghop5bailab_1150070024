package com.example.dnk_1150070024_th3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.*;

import java.text.DecimalFormat;

public class LengthActivity extends AppCompatActivity {

    private String[] units = {
            "Hải lý", "Dặm", "Km", "Lý", "Met", "Yard", "Foot", "Inch"
    };

    private double[][] ratio = {
            {1.0000000, 1.15077945, 1.8520000, 20.2537183, 1852.0000, 2025.37183, 6076.11549, 72913.38853},
            {0.86897624, 1.0000000, 1.6093440, 17.6000, 1609.3440, 1760.0000, 5280.0000, 63360.0000},
            {0.53995680, 0.62137119, 1.0000000, 10.9361330, 1000.0000, 1093.61330, 3280.83990, 39370.07874},
            {0.04937936, 0.05681811, 0.0914400, 1.0000000, 91.4400, 100, 328.084, 3937.00},
            {0.00053996, 0.00062137, 0.0010000, 0.0109361, 1.0000000, 1.0936133, 3.2808399, 39.37007874},
            {0.00049374, 0.00056818, 0.0009144, 0.0030480, 0.9144, 1.0000000, 3.0000000, 36.0000000},
            {0.00016458, 0.00018939, 0.0003048, 0.0010160, 0.3048, 0.3333333, 1.0000000, 12.0000000},
            {0.00001371, 0.00001578, 0.0000254, 0.0000847, 0.0254, 0.02778, 0.08333, 1.0000000}
    };

    private EditText txtNumber;
    private Spinner spnUnit;
    private TextView[] lblResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        txtNumber = findViewById(R.id.txtNumber);
        spnUnit = findViewById(R.id.spnUnit);

        lblResults = new TextView[]{
                findViewById(R.id.lblHaiLy),
                findViewById(R.id.lblDam),
                findViewById(R.id.lblKm),
                findViewById(R.id.lblLy),
                findViewById(R.id.lblMet),
                findViewById(R.id.lblYard),
                findViewById(R.id.lblFoot),
                findViewById(R.id.lblInch)
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnUnit.setAdapter(adapter);

        spnUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                changeLength();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        txtNumber.addTextChangedListener(new TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { changeLength(); }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void changeLength() {

        int idx = spnUnit.getSelectedItemPosition();

        String input = txtNumber.getText().toString();
        if (input.isEmpty()) input = "0";

        double number = Double.parseDouble(input);

        DecimalFormat df = new DecimalFormat("#.#####");

        for (int i = 0; i < lblResults.length; i++) {
            double temp = number * ratio[idx][i];
            lblResults[i].setText(df.format(temp));
        }
    }
}

